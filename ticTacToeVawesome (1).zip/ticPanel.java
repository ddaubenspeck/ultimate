import java.awt.*;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class ticPanel extends JPanel implements ActionListener{

  private JButton[][] piece;
  private int winnerOfBoard;
  private ImageIcon[] icons ={new ImageIcon("FuManHead.png"), new ImageIcon("german.gif")};


  public ticPanel(){
    this.setSize(150,150);
    this.setVisible(true);
    piece = new JButton[3][3];
    
    buildBoard();
  }
  
  public void buildBoard(){
    this.setLayout(new GridLayout(3,3));
    this.setBorder(BorderFactory.createEmptyBorder(5,5,5,5));
    for(int r=0; r<piece.length; r++){
      for(int c=0; c<piece[r].length; c++){
        piece[r][c] = new JButton();
        piece[r][c].setIcon(icons[0]);
        this.add(piece[r][c]);
        
      }
    }
  }

  public void actionPerformed(ActionEvent evt){
    
  }
  
}