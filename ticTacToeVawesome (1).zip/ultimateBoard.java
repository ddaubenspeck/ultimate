import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.*;
import java.awt.event.*;

public class ultimateBoard extends JFrame implements ActionListener{

  private ticPanel[][] games = new ticPanel[3][3];
    
  public ultimateBoard(String title){
    super(title);
    this.setSize(800,800);
    this.setVisible(true);
    buildBoard();
    repaint();
  }

  public void buildBoard(){
    this.setLayout(new GridLayout(3,3));
    
    for(int r=0; r<games.length; r++){
      for(int c=0; c<games[r].length; c++){
        games[r][c]=new ticPanel();
        this.add(games[r][c]);
        
      }
    }
    repaint();
  }

  public void actionPerformed(ActionEvent evt){
    
  }

}