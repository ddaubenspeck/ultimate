import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import java.awt.*;

class Main {
  public static void main(String[] args) {
    ultimateBoard harsh = new ultimateBoard("Ultimate TicTacToe");
  }
}